<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - EduPredict</title>
    <link rel="stylesheet" href="/projecty/public/assets/css/styles.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    .dashboard-container {
        min-height: 100vh;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 20px;
    }
    
    .dashboard-header {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        padding: 15px 0;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .header-content {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .header-left {
        display: flex;
        align-items: center;
    }
    
    .header-left i {
        font-size: 1.5rem;
        color: #2c5aa0;
        margin-right: 12px;
    }
    
    .header-left h1 {
        color: #333;
        margin: 0;
        font-size: 1.5rem;
    }
    
    .header-right {
        display: flex;
        align-items: center;
        gap: 20px;
    }
    
    .user-info {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .user-avatar {
        width: 35px;
        height: 35px;
        background: #2c5aa0;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: bold;
        font-size: 0.9rem;
    }
    
    .logout-btn {
        background: #dc3545;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
        text-decoration: none;
        transition: all 0.3s ease;
    }
    
    .logout-btn:hover {
        background: #c82333;
    }
    
    .dashboard-content {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        margin-bottom: 20px;
    }
    
    .stat-card {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        text-align: center;
        transition: all 0.3s ease;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        background: rgba(255, 255, 255, 1);
    }
    
    .stat-icon {
        width: 50px;
        height: 50px;
        background: linear-gradient(135deg, #2c5aa0, #1e3a8a);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 12px;
        color: white;
        font-size: 1.3rem;
    }
    
    .stat-number {
        font-size: 2rem;
        font-weight: 700;
        color: #2c5aa0;
        margin-bottom: 5px;
    }
    
    .stat-label {
        color: #666;
        font-weight: 500;
        font-size: 0.9rem;
    }
    
    .dashboard-grid {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 20px;
        margin-bottom: 20px;
    }
    
    @media (max-width: 768px) {
        .dashboard-grid {
            grid-template-columns: 1fr;
        }
    }
    
    .chart-card {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .chart-card h3 {
        margin: 0 0 15px 0;
        color: #333;
        font-size: 1.1rem;
    }
    
    .chart-card canvas {
        max-height: 250px !important;
    }
    
    .recent-activity {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        max-height: 400px;
        overflow-y: auto;
    }
    
    .recent-activity h3 {
        margin: 0 0 15px 0;
        color: #333;
        font-size: 1.1rem;
    }
    
    .activity-item {
        display: flex;
        align-items: center;
        padding: 12px 0;
        border-bottom: 1px solid #eee;
    }
    
    .activity-item:last-child {
        border-bottom: none;
    }
    
    .activity-icon {
        width: 35px;
        height: 35px;
        background: #f8f9fa;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 12px;
        color: #2c5aa0;
        font-size: 0.9rem;
        flex-shrink: 0;
    }
    
    .activity-content {
        flex: 1;
        min-width: 0;
    }
    
    .activity-title {
        font-weight: 500;
        color: #333;
        margin-bottom: 3px;
        font-size: 0.9rem;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    
    .activity-time {
        color: #666;
        font-size: 0.8rem;
    }
    
    .quick-actions {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 15px;
    }
    
    .action-card {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        text-align: center;
        transition: all 0.3s ease;
        cursor: pointer;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .action-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        background: rgba(255, 255, 255, 1);
    }
    
    .action-icon {
        width: 45px;
        height: 45px;
        background: linear-gradient(135deg, #2c5aa0, #1e3a8a);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 12px;
        color: white;
        font-size: 1.1rem;
    }
    
    .action-title {
        font-weight: 600;
        color: #333;
        margin-bottom: 5px;
        font-size: 0.95rem;
    }
    
    .action-desc {
        color: #666;
        font-size: 0.85rem;
    }
</style>

<div class="dashboard-container">
    <div class="dashboard-header">
        <div class="header-content">
            <div class="header-left">
                <i class="fas fa-graduation-cap"></i>
                <h1>Admin Dashboard</h1>
            </div>
            <div class="header-right">
                <div class="user-info">
                    <div class="user-avatar">
                        <?php echo strtoupper(substr($_SESSION['name'] ?? 'A', 0, 1)); ?>
                    </div>
                    <div>
                        <div style="font-weight: 500;"><?php echo htmlspecialchars($_SESSION['name'] ?? 'Admin'); ?></div>
                        <div style="font-size: 0.9rem; color: #666;"><?php echo htmlspecialchars($_SESSION['email'] ?? ''); ?></div>
                    </div>
                </div>
                <a href="/projecty/public/index.php?controller=home&action=index" style="background: #28a745; color: white; border: none; padding: 8px 16px; border-radius: 5px; cursor: pointer; text-decoration: none; transition: all 0.3s ease; margin-right: 10px; font-size: 0.9rem;">
                    <i class="fas fa-home"></i> Home
                </a>
                <a href="/projecty/public/index.php?controller=auth&action=logout" class="logout-btn" style="padding: 8px 16px; font-size: 0.9rem;">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </div>
    </div>
    
    <div class="dashboard-content">
        <div class="stats-grid">
            <div class="stat-card" onclick="window.location.href='/projecty/public/index.php?controller=crud&action=index&entity=user'" style="cursor: pointer;">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-number"><?php echo number_format($totalUsers ?? 0); ?></div>
                <div class="stat-label">Total Users</div>
            </div>
            
            <div class="stat-card" onclick="window.location.href='/projecty/public/index.php?controller=crud&action=index&entity=user&role=instructor'" style="cursor: pointer;">
                <div class="stat-icon">
                    <i class="fas fa-chalkboard-teacher"></i>
                </div>
                <div class="stat-number"><?php echo number_format($totalInstructors ?? 0); ?></div>
                <div class="stat-label">Instructors</div>
            </div>
            
            <div class="stat-card" onclick="window.location.href='/projecty/public/index.php?controller=crud&action=index&entity=user&role=student'" style="cursor: pointer;">
                <div class="stat-icon">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="stat-number"><?php echo number_format($atRiskStudents ?? 0); ?></div>
                <div class="stat-label">At-Risk Students</div>
            </div>
            
            <div class="stat-card" onclick="window.location.href='/projecty/public/index.php?controller=crud&action=index&entity=user&role=student'" style="cursor: pointer;">
                <div class="stat-icon">
                    <i class="fas fa-bell"></i>
                </div>
                <div class="stat-number"><?php echo number_format($totalStudents ?? 0); ?></div>
                <div class="stat-label">Total Students</div>
            </div>
        </div>
        
        <div class="dashboard-grid">
            <div class="chart-card">
                <h3>Academic Performance Trends</h3>
                <canvas id="performanceChart" style="max-height: 250px;"></canvas>
            </div>
            
            <div class="recent-activity">
                <h3>Recent Activity</h3>
                <?php if (!empty($recentUsers)): ?>
                    <?php foreach ($recentUsers as $user): ?>
                        <div class="activity-item">
                            <div class="activity-icon">
                                <i class="fas fa-user-plus"></i>
                            </div>
                            <div class="activity-content">
                                <div class="activity-title"><?php echo htmlspecialchars($user['name']); ?> registered</div>
                                <div class="activity-time"><?php echo isset($user['created_at']) ? date('M j, Y g:i A', strtotime($user['created_at'])) : 'Recently'; ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="activity-item">
                        <div class="activity-icon">
                            <i class="fas fa-info-circle"></i>
                        </div>
                        <div class="activity-content">
                            <div class="activity-title">No recent activity</div>
                            <div class="activity-time">System is ready</div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="quick-actions">
            <div class="action-card" onclick="window.location.href='/projecty/public/index.php?controller=crud&action=index&entity=user'">
                <div class="action-icon">
                    <i class="fas fa-users-cog"></i>
                </div>
                <div class="action-title">Manage Users</div>
                <div class="action-desc">Add, edit, or remove users</div>
            </div>
            
            <div class="action-card" onclick="window.location.href='/projecty/public/index.php?controller=crud&action=index&entity=course'">
                <div class="action-icon">
                    <i class="fas fa-book"></i>
                </div>
                <div class="action-title">Manage Courses</div>
                <div class="action-desc">Add or edit courses</div>
            </div>
            
            <div class="action-card" onclick="window.location.href='/projecty/public/index.php?controller=crud&action=index&entity=student'">
                <div class="action-icon">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <div class="action-title">Manage Students</div>
                <div class="action-desc">View all students</div>
            </div>
            
            <div class="action-card" onclick="window.location.href='/projecty/public/enrollment'">
                <div class="action-icon">
                    <i class="fas fa-book-reader"></i>
                </div>
                <div class="action-title">Manage Enrollments</div>
                <div class="action-desc">Enroll students in courses</div>
            </div>
            
            <div class="action-card" onclick="window.location.href='/projecty/utilities/manage-student-gpa.php'">
                <div class="action-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="action-title">Manage GPA & Attendance</div>
                <div class="action-desc">Add/update student GPA</div>
            </div>
            
            <div class="action-card" onclick="window.location.href='/projecty/utilities/train-knn-model.php'">
                <div class="action-icon">
                    <i class="fas fa-brain"></i>
                </div>
                <div class="action-title">Train KNN Model</div>
                <div class="action-desc">Train ML prediction model</div>
            </div>
            
            <div class="action-card" onclick="window.location.href='/projecty/utilities/database-viewer.php'">
                <div class="action-icon">
                    <i class="fas fa-database"></i>
                </div>
                <div class="action-title">Database Viewer</div>
                <div class="action-desc">View database contents</div>
            </div>
            
            <div class="action-card" onclick="window.location.href='/projecty/public/index.php?controller=menu&action=index'">
                <div class="action-icon">
                    <i class="fas fa-bars"></i>
                </div>
                <div class="action-title">Menu Management</div>
                <div class="action-desc">Manage navigation menu</div>
            </div>
            
            <div class="action-card" onclick="window.location.href='/projecty/public/predictions/train'">
                <div class="action-icon">
                    <i class="fas fa-brain"></i>
                </div>
                <div class="action-title">Train KNN Model</div>
                <div class="action-desc">Train ML prediction model</div>
            </div>
            
            <div class="action-card" onclick="window.location.href='/projecty/public/index.php?controller=prediction&action=index'">
                <div class="action-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="action-title">View Predictions</div>
                <div class="action-desc">View all predictions</div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Performance Chart
    const ctx = document.getElementById('performanceChart').getContext('2d');
    const performanceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Average GPA',
                data: [3.2, 3.4, 3.1, 3.5, 3.6, 3.7],
                borderColor: '#2c5aa0',
                backgroundColor: 'rgba(44, 90, 160, 0.1)',
                tension: 0.4
            }, {
                label: 'At-Risk Students',
                data: [45, 38, 52, 41, 35, 28],
                borderColor: '#dc3545',
                backgroundColor: 'rgba(220, 53, 69, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            aspectRatio: 2,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        font: {
                            size: 11
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        font: {
                            size: 10
                        }
                    }
                },
                x: {
                    ticks: {
                        font: {
                            size: 10
                        }
                    }
                }
            }
        }
    });
</script>
</body>
</html>



