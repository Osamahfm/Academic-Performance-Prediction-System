<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - EduPredict</title>
    <link rel="stylesheet" href="/projecty/public/assets/css/styles.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    .dashboard-container {
        min-height: 100vh;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 20px;
    }
    
    .dashboard-header {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        padding: 15px 0;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .header-content {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .header-left {
        display: flex;
        align-items: center;
    }
    
    .header-left i {
        font-size: 1.5rem;
        color: #2c5aa0;
        margin-right: 12px;
    }
    
    .header-left h1 {
        color: #333;
        margin: 0;
        font-size: 1.5rem;
    }
    
    .header-right {
        display: flex;
        align-items: center;
        gap: 20px;
    }
    
    .user-info {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .user-avatar {
        width: 35px;
        height: 35px;
        background: #2c5aa0;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: bold;
        font-size: 0.9rem;
    }
    
    .logout-btn {
        background: #dc3545;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
        text-decoration: none;
        transition: all 0.3s ease;
    }
    
    .logout-btn:hover {
        background: #c82333;
    }
    
    .dashboard-content {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        margin-bottom: 20px;
    }
    
    .stat-card {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        text-align: center;
        transition: all 0.3s ease;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        background: rgba(255, 255, 255, 1);
    }
    
    .stat-icon {
        width: 50px;
        height: 50px;
        background: linear-gradient(135deg, #2c5aa0, #1e3a8a);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 12px;
        color: white;
        font-size: 1.3rem;
    }
    
    .stat-number {
        font-size: 2rem;
        font-weight: 700;
        color: #2c5aa0;
        margin-bottom: 5px;
    }
    
    .stat-label {
        color: #666;
        font-weight: 500;
        font-size: 0.9rem;
    }
    
    .dashboard-grid {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 20px;
        margin-bottom: 20px;
    }
    
    @media (max-width: 768px) {
        .dashboard-grid {
            grid-template-columns: 1fr;
        }
    }
    
    .chart-card {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .chart-card h3 {
        margin: 0 0 15px 0;
        color: #333;
        font-size: 1.1rem;
    }
    
    .chart-card canvas {
        max-height: 250px !important;
    }
    
    .recent-grades {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        max-height: 400px;
        overflow-y: auto;
    }
    
    .recent-grades h3 {
        margin: 0 0 15px 0;
        color: #333;
        font-size: 1.1rem;
    }
    
    .grade-item {
        display: flex;
        align-items: center;
        padding: 12px 0;
        border-bottom: 1px solid #eee;
    }
    
    .grade-item:last-child {
        border-bottom: none;
    }
    
    .grade-icon {
        width: 35px;
        height: 35px;
        background: #f8f9fa;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 12px;
        color: #2c5aa0;
        font-size: 0.9rem;
        flex-shrink: 0;
    }
    
    .grade-content {
        flex: 1;
        min-width: 0;
    }
    
    .grade-course {
        font-weight: 500;
        color: #333;
        margin-bottom: 3px;
        font-size: 0.9rem;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    
    .grade-details {
        color: #666;
        font-size: 0.8rem;
    }
    
    .grade-score {
        font-weight: 600;
        color: #2c5aa0;
    }
    
    .quick-actions {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 15px;
        margin-top: 20px;
    }
    
    .action-card {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        text-align: center;
        transition: all 0.3s ease;
        cursor: pointer;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .action-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        background: rgba(255, 255, 255, 1);
    }
    
    .action-icon {
        width: 45px;
        height: 45px;
        background: linear-gradient(135deg, #2c5aa0, #1e3a8a);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 12px;
        color: white;
        font-size: 1.1rem;
    }
    
    .action-title {
        font-weight: 600;
        color: #333;
        margin-bottom: 5px;
        font-size: 0.95rem;
    }
    
    .action-desc {
        color: #666;
        font-size: 0.85rem;
    }
</style>

<div class="dashboard-container">
    <div class="dashboard-header">
        <div class="header-content">
            <div class="header-left">
                <i class="fas fa-user-graduate"></i>
                <h1>Student Dashboard</h1>
            </div>
            <div class="header-right">
                <div class="user-info">
                    <div class="user-avatar">
                        <?php echo strtoupper(substr($_SESSION['name'] ?? 'S', 0, 1)); ?>
                    </div>
                    <div>
                        <div style="font-weight: 500;"><?php echo htmlspecialchars($_SESSION['name'] ?? 'Student'); ?></div>
                        <div style="font-size: 0.9rem; color: #666;"><?php echo htmlspecialchars($_SESSION['email'] ?? ''); ?></div>
                    </div>
                </div>
                <a href="/projecty/public/index.php?controller=home&action=index" style="background: #28a745; color: white; border: none; padding: 8px 16px; border-radius: 5px; cursor: pointer; text-decoration: none; transition: all 0.3s ease; margin-right: 10px; font-size: 0.9rem;">
                    <i class="fas fa-home"></i> Home
                </a>
                <a href="/projecty/public/index.php?controller=auth&action=logout" class="logout-btn" style="padding: 8px 16px; font-size: 0.9rem;">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </div>
    </div>
    
    <div class="dashboard-content">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-book"></i>
                </div>
                <div class="stat-number"><?php echo !empty($grades) ? count($grades) : 0; ?></div>
                <div class="stat-label">Enrolled Courses</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="stat-number"><?php echo ($student && isset($student['gpa']) && $student['gpa'] !== null) ? number_format((float)$student['gpa'], 2) : '0.00'; ?></div>
                <div class="stat-label">Current GPA</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <div class="stat-number"><?php echo ($student && isset($student['attendance_rate']) && $student['attendance_rate'] !== null) ? number_format((float)$student['attendance_rate'], 0) : 0; ?>%</div>
                <div class="stat-label">Attendance Rate</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div class="stat-number"><?php echo ($student && isset($student['risk_level']) && $student['risk_level'] !== null) ? ucfirst($student['risk_level']) : 'Low'; ?></div>
                <div class="stat-label">Risk Level</div>
            </div>
        </div>
        
        <div class="dashboard-grid">
            <div class="chart-card">
                <h3>Performance Overview</h3>
                <canvas id="performanceChart" style="max-height: 250px;"></canvas>
            </div>
            
            <div class="recent-grades">
                <h3>Recent Grades</h3>
                <?php if (!empty($grades)): ?>
                    <?php foreach (array_slice($grades, 0, 5) as $grade): ?>
                        <div class="grade-item">
                            <div class="grade-icon">
                                <i class="fas fa-graduation-cap"></i>
                            </div>
                            <div class="grade-content">
                                <div class="grade-course"><?php echo htmlspecialchars($grade['course_name'] ?? 'Course'); ?></div>
                                <div class="grade-details">
                                    <?php echo ucfirst($grade['assignment_type'] ?? 'Assignment'); ?> - 
                                    <span class="grade-score"><?php echo number_format((float)($grade['grade'] ?? 0), 2); ?>/<?php echo number_format((float)($grade['max_grade'] ?? 100), 2); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="grade-item">
                        <div class="grade-icon">
                            <i class="fas fa-info-circle"></i>
                        </div>
                        <div class="grade-content">
                            <div class="grade-course">No grades recorded yet</div>
                            <div class="grade-details">Check back after assignments are graded</div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Prediction Summary Card -->
        <?php if ($overallPrediction): ?>
            <?php
            $predictedGrade = $overallPrediction['predicted_grade'] ?? 0;
            $gradeLetter = '';
            $gradeClass = '';
            $message = '';
            
            if ($predictedGrade >= 90) {
                $gradeLetter = 'A';
                $gradeClass = 'excellent';
                $message = 'Excellent!';
            } elseif ($predictedGrade >= 80) {
                $gradeLetter = 'B';
                $gradeClass = 'good';
                $message = 'Good!';
            } elseif ($predictedGrade >= 70) {
                $gradeLetter = 'C';
                $gradeClass = 'average';
                $message = 'Average';
            } elseif ($predictedGrade >= 60) {
                $gradeLetter = 'D';
                $gradeClass = 'below';
                $message = 'Needs Improvement';
            } else {
                $gradeLetter = 'F';
                $gradeClass = 'failing';
                $message = 'At Risk';
            }
            ?>
            <div class="chart-card" style="margin-bottom: 20px; background: linear-gradient(135deg, <?php echo $gradeClass === 'excellent' ? '#28a745' : ($gradeClass === 'good' ? '#2c5aa0' : ($gradeClass === 'average' ? '#ffc107' : ($gradeClass === 'below' ? '#fd7e14' : '#dc3545'))); ?>, <?php echo $gradeClass === 'excellent' ? '#20c997' : ($gradeClass === 'good' ? '#1e3a8a' : ($gradeClass === 'average' ? '#ff9800' : ($gradeClass === 'below' ? '#e65100' : '#c82333'))); ?>); color: white;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h3 style="margin: 0 0 10px 0; color: white; font-size: 1.1rem;">
                            <i class="fas fa-chart-line"></i> Predicted Performance
                        </h3>
                        <div style="font-size: 2.5rem; font-weight: bold; margin-bottom: 5px;">
                            <?php echo number_format($predictedGrade, 1); ?>%
                        </div>
                        <div style="font-size: 1.2rem; opacity: 0.9;">
                            Grade: <strong><?php echo $gradeLetter; ?></strong> - <?php echo $message; ?>
                        </div>
                        <div style="margin-top: 10px; font-size: 0.9rem; opacity: 0.85;">
                            Confidence: <?php echo number_format(($overallPrediction['confidence_score'] ?? 0) * 100, 0); ?>%
                        </div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 4rem; opacity: 0.3; line-height: 1;">
                            <?php echo $gradeLetter; ?>
                        </div>
                    </div>
                </div>
                <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid rgba(255,255,255,0.3);">
                    <a href="/projecty/public/index.php?controller=prediction&action=index" style="display: inline-block; background: rgba(255,255,255,0.2); color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; transition: all 0.3s;">
                        <i class="fas fa-arrow-right"></i> View Detailed Predictions
                    </a>
                </div>
            </div>
        <?php endif; ?>
        
        <div class="quick-actions" style="margin-top: 20px;">
            <div class="action-card" onclick="window.location.href='/projecty/public/index.php?controller=prediction&action=index'" style="cursor: pointer;">
                <div class="action-icon">
                    <i class="fas fa-brain"></i>
                </div>
                <div class="action-title">View Predictions</div>
                <div class="action-desc">See detailed ML predictions</div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Performance Chart
    const ctx = document.getElementById('performanceChart').getContext('2d');
    const performanceChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Excellent (A)', 'Good (B)', 'Average (C)', 'Below Average (D)', 'Failing (F)'],
            datasets: [{
                data: [30, 40, 20, 8, 2],
                backgroundColor: [
                    '#28a745',
                    '#2c5aa0',
                    '#ffc107',
                    '#fd7e14',
                    '#dc3545'
                ],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            aspectRatio: 1.5,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        font: {
                            size: 11
                        }
                    }
                }
            }
        }
    });
</script>
</body>
</html>



